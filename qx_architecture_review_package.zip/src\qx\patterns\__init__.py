"""Pattern detection engines."""

