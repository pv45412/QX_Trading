"""Smart Order Router for paper and live order placement."""

from datetime import datetime, timezone
import logging
from typing import Any
from qx.execution.models import ExecutionFill, Order, OrderRequest, OrderSide, OrderStatus, OrderType

logger = logging.getLogger(__name__)


class OrderRouter:
    """In-memory smart order routing and paper execution engine."""

    def __init__(self) -> None:
        self._orders: dict[str, Order] = {}

    def calculate_live_basis(self, es_price: float, spx_price: float) -> dict[str, Any]:
        """Calculate live basis spread (es_price - spx_price) at the instant of order generation."""
        from qx.market.price_normalization import calculate_es_spx_basis
        return calculate_es_spx_basis(es_price, spx_price)

    def get_batch_basis_snapshot(self, market_data_provider: Any, symbols: tuple[str, str] = ("/ES", "$SPX")) -> dict[str, Any]:
        """Fetch /ES futures and SPX cash quotes together in a batch request, preserving quote timestamps.
        
        Eliminates network latency skew between sequential quote calls and captures quote timestamps.
        """
        sym_es, sym_spx = symbols
        ts_es, ts_spx = None, None
        p_es, p_spx = 0.0, 0.0

        if hasattr(market_data_provider, "get_quotes"):
            quotes = market_data_provider.get_quotes([sym_es, sym_spx])
            q_es = quotes.get(sym_es) or quotes.get("ES=F")
            q_spx = quotes.get(sym_spx) or quotes.get("SPX")
            p_es = float(getattr(q_es, "last_price", getattr(q_es, "last", 0.0))) if q_es else 0.0
            p_spx = float(getattr(q_spx, "last_price", getattr(q_spx, "last", 0.0))) if q_spx else 0.0
            ts_es = getattr(q_es, "timestamp", getattr(q_es, "quote_time", None))
            ts_spx = getattr(q_spx, "timestamp", getattr(q_spx, "quote_time", None))
        else:
            q_es = market_data_provider.get_quote(sym_es)
            q_spx = market_data_provider.get_quote(sym_spx)
            p_es = float(getattr(q_es, "last_price", getattr(q_es, "last", 0.0))) if q_es else 0.0
            p_spx = float(getattr(q_spx, "last_price", getattr(q_spx, "last", 0.0))) if q_spx else 0.0
            ts_es = getattr(q_es, "timestamp", getattr(q_es, "quote_time", None))
            ts_spx = getattr(q_spx, "timestamp", getattr(q_spx, "quote_time", None))

        res = self.calculate_live_basis(p_es, p_spx)
        res["es_timestamp"] = str(ts_es) if ts_es else None
        res["spx_timestamp"] = str(ts_spx) if ts_spx else None
        return res

    def get_atomic_basis_from_quotes(self, market_data_provider: Any, symbols: tuple[str, str] = ("/ES", "$SPX")) -> dict[str, Any]:
        """Backwards compatibility alias for get_batch_basis_snapshot."""
        return self.get_batch_basis_snapshot(market_data_provider, symbols)

    def get_live_spx_strike(self, es_target: float, es_price: float, spx_price: float) -> float:
        """Convert /ES trigger target level to SPX cash strike using instantaneous live basis.
        
        Formula: live_basis = es_price - spx_price
        target_spx_cash = trigger_es_level - live_basis (since /ES trades at a premium to cash SPX).
        """
        from qx.market.price_normalization import calculate_es_spx_basis, normalize_es_target_to_spx
        basis_info = calculate_es_spx_basis(es_price, spx_price)
        live_basis = basis_info["basis"] if basis_info["is_valid"] else 0.0
        return normalize_es_target_to_spx(es_target, live_basis)

    def validate_execution_eligibility(self, trade_object: dict[str, Any] | Any) -> tuple[bool, str]:
        """Centralized execution rule: only VERIFIED trade objects can become executable order proposals."""
        pub_state = None
        executable = True
        if isinstance(trade_object, dict):
            pub_state = trade_object.get("publication_state") or trade_object.get("state")
            executable = trade_object.get("executable", True)
        elif hasattr(trade_object, "publication_state"):
            pub_state = getattr(trade_object, "publication_state")
            executable = getattr(trade_object, "executable", True)

        if pub_state is not None and str(pub_state).upper() != "VERIFIED":
            return False, f"Trade object is non-executable: publication_state is '{pub_state}'. Only VERIFIED trade objects are eligible for order execution."
        if executable is False:
            return False, "Trade object is explicitly marked executable=False. Only executable trade objects can become order proposals."
        return True, ""

    def submit_order(
        self,
        request: OrderRequest,
        current_market_price: float | None = None,
        es_price: float | None = None,
        spx_price: float | None = None,
    ) -> Order:
        """Submit a new order request with optional dynamic basis tracking and immediate simulation fill."""
        # Calculate instantaneous live basis if both /ES and SPX prices are provided
        notes = request.notes
        if es_price is not None and spx_price is not None and es_price > 0 and spx_price > 0:
            basis_info = self.calculate_live_basis(es_price, spx_price)
            live_basis = basis_info["basis"]
            basis_note = f"[LIVE BASIS AT ORDER GENERATION: {live_basis:.2f} (ES: {es_price}, SPX: {spx_price})]"
            notes = f"{notes} | {basis_note}" if notes else basis_note

        order = Order(
            symbol=request.symbol.upper(),
            side=request.side,
            order_type=request.order_type,
            quantity=request.quantity,
            limit_price=request.limit_price,
            stop_price=request.stop_price,
            bracket=request.bracket,
            time_in_force=request.time_in_force,
            status=OrderStatus.SUBMITTED,
        )
        if notes:
            order.reject_reason = None  # preserve notes in order structure

        # Pre-trade publication eligibility check
        is_eligible, elig_reason = self.validate_execution_eligibility({
            "publication_state": request.publication_state,
            "executable": request.executable,
        })
        if not is_eligible:
            order.status = OrderStatus.REJECTED
            order.reject_reason = elig_reason
            self._orders[order.order_id] = order
            return order

        # Pre-trade validation check
        if request.order_type in {OrderType.LIMIT, OrderType.STOP_LIMIT} and request.limit_price is None:
            order.status = OrderStatus.REJECTED
            order.reject_reason = "Limit price is required for LIMIT and STOP_LIMIT orders."
            self._orders[order.order_id] = order
            return order

        if request.order_type in {OrderType.STOP, OrderType.STOP_LIMIT} and request.stop_price is None:
            order.status = OrderStatus.REJECTED
            order.reject_reason = "Stop price is required for STOP and STOP_LIMIT orders."
            self._orders[order.order_id] = order
            return order

        self._orders[order.order_id] = order

        # Auto-fill MARKET orders if market price is provided
        if request.order_type == OrderType.MARKET and current_market_price is not None and current_market_price > 0:
            self.execute_fill(order.order_id, fill_price=current_market_price, fill_quantity=order.quantity)

        return self._orders[order.order_id]

    def execute_fill(self, order_id: str, fill_price: float, fill_quantity: float) -> ExecutionFill:
        """Execute a fill against an active order."""
        if order_id not in self._orders:
            raise KeyError(f"Order ID {order_id} not found.")

        order = self._orders[order_id]
        if order.status in {OrderStatus.FILLED, OrderStatus.CANCELED, OrderStatus.REJECTED}:
            raise ValueError(f"Cannot fill order {order_id} with status {order.status}.")

        fill = ExecutionFill(
            order_id=order_id,
            symbol=order.symbol,
            side=order.side,
            filled_quantity=fill_quantity,
            fill_price=fill_price,
            filled_at=datetime.now(timezone.utc),
        )

        order.fills.append(fill)
        order.filled_quantity += fill_quantity
        order.updated_at = datetime.now(timezone.utc)

        if order.filled_quantity >= order.quantity:
            order.status = OrderStatus.FILLED
        else:
            order.status = OrderStatus.PARTIALLY_FILLED

        return fill

    def cancel_order(self, order_id: str) -> Order:
        """Cancel an open or pending order."""
        if order_id not in self._orders:
            raise KeyError(f"Order ID {order_id} not found.")

        order = self._orders[order_id]
        if order.status == OrderStatus.FILLED:
            raise ValueError(f"Cannot cancel order {order_id} because it is already FILLED.")

        order.status = OrderStatus.CANCELED
        order.updated_at = datetime.now(timezone.utc)
        return order

    def get_order(self, order_id: str) -> Order | None:
        """Retrieve an order by ID."""
        return self._orders.get(order_id)

    def list_orders(self, symbol: str | None = None) -> list[Order]:
        """List orders optionally filtered by ticker symbol."""
        if symbol:
            sym_clean = symbol.strip().upper()
            return [o for o in self._orders.values() if o.symbol == sym_clean]
        return list(self._orders.values())
