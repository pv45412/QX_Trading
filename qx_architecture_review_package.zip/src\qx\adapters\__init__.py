"""External system adapters."""

