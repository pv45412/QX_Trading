"""Shared scanner data models."""

