"""Configuration loading and settings."""

