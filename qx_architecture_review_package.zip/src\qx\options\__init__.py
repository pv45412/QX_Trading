"""Options idea generation modules."""
