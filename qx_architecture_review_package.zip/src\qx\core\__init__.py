"""Core scanner orchestration."""

