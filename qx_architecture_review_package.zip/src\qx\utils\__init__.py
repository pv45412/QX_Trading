"""Shared utility helpers."""

