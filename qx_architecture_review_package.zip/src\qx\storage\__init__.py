"""Persistence adapters."""

