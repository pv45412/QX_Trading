"""Chart generation helpers."""

